function nav_main(hrf) {

 document.write('<div class="nav-scroller">');
 document.write('<nav class="nav-scroller__items dragscroll">');

 if(hrf=="main") {
   document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Главная</a>');
 }
 else {
  document.write('<a href="/" class="nav-scroller__item">Главная</a>');
 }
  if(hrf=="about") {
   document.write('<a href="#" class="nav-scroller__item  nav-scroller__item_active">Сведения об образовательной организации</a>');
  }
  else {
   document.write('<a href="/about" class="nav-scroller__item">Сведения об образовательной организации</a>');
 }
  if(hrf=="raspisanie") {
    document.write(' <a href="#" class="nav-scroller__item   nav-scroller__item_active">Расписание</a>');
   }
  else {
   document.write(' <a href="/raspisanie" class="nav-scroller__item">Расписание</a>');
  }
  if(hrf=="links") {
    document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Полезные ссылки</a>');
  }
  else {
    document.write('<a href="/links" class="nav-scroller__item">Полезные ссылки</a>');
  }
  if(hrf=="contacts") {
    document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Контакты</a>');
  }
  else {
    document.write('<a href="/contacts" class="nav-scroller__item">Контакты</a>');
  }
 document.write('</nav>');
 document.write('</div>');
}
